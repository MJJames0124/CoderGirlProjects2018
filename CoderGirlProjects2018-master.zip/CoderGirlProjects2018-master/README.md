# CoderGirlProjects2018
This is a collection of projects submitted for LaunchCode's CoderGirl  Java Program, Summer 2018
